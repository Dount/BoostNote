package com.lypeer.myaidldemo;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class BookService extends Service {
    private List<Book> list;
    @Override
    public void onCreate() {
        super.onCreate();
        list = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            Book book = new Book("第" + i + "本书");
            list.add(book);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    //通过客户端返回过来的对象实例。
    private BookManager.Stub bookManager = new BookManager.Stub(){

        @Override
        public List<Book> getBookList() throws RemoteException {
            Log.i("zhouwei", "getBookList");
            return list;
        }

        @Override
        public void addBook(Book book) throws RemoteException {
            Log.i("zhouwei", "addBook");
            if (book != null) {
                list.add(book);
            }
            Log.i("zhouwei", book.toString());
        }
    };


    @Override
    public IBinder onBind(Intent intent) {
        Log.i("zhouwei","onBind");
        return bookManager;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.i("zhouwei","onUnbind");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        Log.i("zhouwei","onDestroy");
        super.onDestroy();
    }

}
