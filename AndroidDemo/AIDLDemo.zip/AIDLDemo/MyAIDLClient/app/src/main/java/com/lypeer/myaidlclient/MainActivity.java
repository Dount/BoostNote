package com.lypeer.myaidlclient;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.lypeer.myaidldemo.Book;
import com.lypeer.myaidldemo.BookManager;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private BookManager manager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button1 = findViewById(R.id.textView1);
        Button button2 = findViewById(R.id.textView2);
        Button button3 = findViewById(R.id.textView3);
        Button button4 = findViewById(R.id.textView4);
        button1.setOnClickListener(new click());
        button2.setOnClickListener(new click());
        button3.setOnClickListener(new click());
        button4.setOnClickListener(new click());
    }

    public class click implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.textView1:
                    Intent intent=new Intent("android.lypper.action.BookService");
                    intent.setPackage("com.lypeer.myaidldemo");
                    bindService(intent,conn, Context.BIND_AUTO_CREATE);
                    break;
                case R.id.textView2:
                    try {
                        if(manager!=null){
                            List<Book> list=manager.getBookList();
                            Toast.makeText(MainActivity.this,"获取Book的列表="+list,Toast.LENGTH_SHORT).show();
                        }
                        else {
                            Toast.makeText(MainActivity.this,"还没有连接成功",Toast.LENGTH_SHORT).show();
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                    break;
                case R.id.textView3:
                    Book book = new Book("圣经");
                    try {
                    if(manager!=null){
                        manager.addBook(book);
                    }
                    else {
                        Toast.makeText(MainActivity.this,"还没有连接成功",Toast.LENGTH_SHORT).show();
                    }
                }catch (RemoteException e){
                    e.printStackTrace();
                }
                    break;
                case R.id.textView4:
                    if(manager!=null){
                        unbindService(conn);
                        manager=null;
                    }
            }
        }
    }

    ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            manager = BookManager.Stub.asInterface(service);
            Log.i("zhouwei","连接成功,Manager="+manager);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            manager=null;
        }
    };
}

