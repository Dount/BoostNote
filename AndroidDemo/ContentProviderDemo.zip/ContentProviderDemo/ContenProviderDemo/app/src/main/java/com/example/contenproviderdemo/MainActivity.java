package com.example.contenproviderdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.contenproviderdemo.Fragment.Fragment1;
import com.example.contenproviderdemo.Fragment.Fragment2;

public class MainActivity extends AppCompatActivity {

    private Fragment1 fragment1;
    private Fragment2 fragment2;
    private FragmentManager fragmentManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button1 =findViewById(R.id.Fragment1);
        Button button2 = findViewById(R.id.Fragment2);
        button1.setOnClickListener(new Click());
        button2.setOnClickListener(new Click());
        fragmentManager = getSupportFragmentManager();
        selectFragment(0);
    }

    public class Click implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.Fragment1:
                    selectFragment(0);
                    break;
                case R.id.Fragment2:
                    selectFragment(1);
                    break;
                default:
                    break;
            }
        }
    }

    public void selectFragment(int select){
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        hide(fragmentTransaction);
        if(select==0){
            if(fragment1==null){
                fragment1=new Fragment1();
                fragmentTransaction.add(R.id.framelayout,fragment1);
            }else {
                fragmentTransaction.show(fragment1);
            }
        }
        if(select==1){
            if(fragment2==null){
                fragment2=new Fragment2();
                fragmentTransaction.add(R.id.framelayout,fragment2);
            }
            else {
                fragmentTransaction.show(fragment2);
            }
        }
        fragmentTransaction.commit();
    }

    public void hide(FragmentTransaction fragmentTransaction){
        if(fragment1!=null){
            fragmentTransaction.hide(fragment1);
        }
        if(fragment2!=null){
            fragmentTransaction.hide(fragment2);
        }
    }
}
