package com.example.contenproviderdemo;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;

public class MyProvider extends ContentProvider {

    private Context mContext;
    DBHelper mDbHelper =null;
    SQLiteDatabase db=null;

    public static final String AUTOHORITY = "cn.scu.myprovider";

    public static final int User_Code =1 ;
    public static final int Job_Code =2;

    private static final UriMatcher mMatcher;
    static {
        mMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        mMatcher.addURI(AUTOHORITY,"user",User_Code);
        mMatcher.addURI(AUTOHORITY,"job",Job_Code);
        // 若URI资源路径 = content://cn.scu.myprovider/user ，则返回注册码User_Code
        // 若URI资源路径 = content://cn.scu.myprovider/job ，则返回注册码Job_Code
    }


    @Override
    public boolean onCreate() {
        mContext =getContext();
        Thread thread=new Thread(new Runnable() {
            @Override
            public void run() {
                mDbHelper=new DBHelper(mContext);
                db=mDbHelper.getWritableDatabase();
                // 初始化两个表的数据(先清空两个表,再各加入一个记录)
                db.execSQL("delete from user");
                db.execSQL("insert into user values(1,'Carson');");
                db.execSQL("insert into user values(2,'Kobe');");

                db.execSQL("delete from job");
                db.execSQL("insert into job values(1,'Android');");
                db.execSQL("insert into job values(2,'iOS');");
            }
        });
        thread.start();

        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        String table = getTableName(uri);

        Cursor cursor =db.query(table,projection,selection,selectionArgs,null,null,sortOrder,null);

        return cursor;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        String table =getTableName(uri);
        db.insert(table,null,values);
        mContext.getContentResolver().notifyChange(uri,null);
        return uri;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        String table =getTableName(uri);
        db.delete(table,selection,selectionArgs);
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        String table =getTableName(uri);
        db.update(table,values,selection,selectionArgs);
        return 0;
    }


    public String getTableName(Uri uri){
        String tableName=null;
        switch (mMatcher.match(uri)){
            case User_Code:
                tableName = DBHelper.USER_TABLE_NAME;
                break;
            case Job_Code:
                tableName = DBHelper.JOB_TABLE_NAME;
                break;
        }
        return tableName;
    }
}
