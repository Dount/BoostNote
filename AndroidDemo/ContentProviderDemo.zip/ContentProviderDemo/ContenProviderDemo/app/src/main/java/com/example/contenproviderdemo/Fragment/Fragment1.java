package com.example.contenproviderdemo.Fragment;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.contenproviderdemo.R;

public class Fragment1 extends Fragment {

    private Uri uri;
    private Uri uri_job;
    private ContentResolver resolver;
    private TextView textMesaage;
    private int clicknum=3;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment1,container,false);
        uri = Uri.parse("content://cn.scu.myprovider/user");
        uri_job = Uri.parse("content://cn.scu.myprovider/job");
        init(view);
        return view;
    }

    public void init(View view){
        Button insertButton = view.findViewById(R.id.insert_data);
        Button selectButton = view.findViewById(R.id.select_data);
        Button deleteButton = view.findViewById(R.id.delete_data);
        Button updateButton = view.findViewById(R.id.update_data);
        textMesaage = view.findViewById(R.id.data_text);
        insertButton.setOnClickListener(new Click());
        selectButton.setOnClickListener(new Click());
        deleteButton.setOnClickListener(new Click());
        updateButton.setOnClickListener(new Click());
        resolver = getContext().getContentResolver();
    }


    public class Click implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.insert_data:
                    insertData(clicknum);
                    break;
                case R.id.select_data:
                    selectData();
                    break;
                case R.id.delete_data:
                    deleteData();
                    break;
                case R.id.update_data:
                    updateData();
                    break;
            }
        }
    }

    public void insertData(int num){
        //插入表中数据
        ContentValues values =new  ContentValues();
        values.put("_id",num);
        values.put("name","Iversion");
        //通过ContentResolver根据URL,向ContentProvider中插入数据.
        resolver.insert(uri,values);
        clicknum++;
    }


    public void selectData(){
        //通过ContentResolver向ContentProvider中查询数据
        Cursor cursor =resolver.query(uri,new String[]{"_id","name"},null,null,null);
        String message="";
        while (cursor.moveToNext()){
            message=message+"query book:"+cursor.getInt(0)+" "+cursor.getString(1)+"\n";
        }
        textMesaage.setText(message);
        //关闭游标
        cursor.close();
    }

    public void deleteData(){
        resolver.delete(uri,"_id=?",new String[]{String.valueOf(clicknum-1)});
    }

    public void updateData(){
        ContentValues values =new  ContentValues();
        values.put("name","my book");
        resolver.update(uri,values,"_id=?",new String[]{String.valueOf(clicknum-1)});
    }

    public void other(){
        /**
         *
         * 对job表进行操作
         */
        // 和上述类似,只是URI需要更改,从而匹配不同的URI CODE,从而找到不同的数据资源


        // 插入表中数据
        ContentValues values2 = new ContentValues();
        values2.put("_id", 3);
        values2.put("job", "NBA Player");

        // 获取ContentResolver
        ContentResolver resolver2 =  getContext().getContentResolver();
        // 通过ContentResolver 根据URI 向ContentProvider中插入数据
        resolver2.insert(uri_job,values2);

        // 通过ContentResolver 向ContentProvider中查询数据
        Cursor cursor2 = resolver2.query(uri_job, new String[]{"_id","job"}, null, null, null);
        while (cursor2.moveToNext()){
            Log.i("zhouwei","query job:" + cursor2.getInt(0) +" "+ cursor2.getString(1));
            // 将表中数据全部输出
        }
        cursor2.close();
        // 关闭游标
    }

}
